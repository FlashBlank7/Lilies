import pandas as pd
import numpy as np
from scipy import signal, integrate
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── Read data ──────────────────────────────────────────────────
df = pd.read_excel('data/正常数据集/device001_label_data_202502181136.xlsx')

# ── Select cycle: Row 370 (开,8F) → Row 420 (关,8F) ────────────
cycle_start = 370  # 开
cycle_end   = 420  # 关
cycle = df.iloc[cycle_start:cycle_end+1].copy().reset_index(drop=False)
n = len(cycle)

# Sampling rate estimation from timestamps
t0 = cycle['create_dt'].iloc[0]
t1 = cycle['create_dt'].iloc[-1]
duration_s = (t1 - t0).total_seconds()
fs = (n - 1) / duration_s  # Hz
print(f"Cycle: rows {cycle_start}–{cycle_end} ({n} samples)")
print(f"Duration: {duration_s:.2f} s, Sampling rate: {fs:.2f} Hz")
print(f"Floor: {cycle['floor'].iloc[0]} → {cycle['floor'].iloc[-1]}")

# ── Butterworth low-pass filter ────────────────────────────────
cutoff = 1.5   # Hz
order  = 4
nyq = 0.5 * fs
b, a = signal.butter(order, cutoff / nyq, btype='low')

def filt(signal_1d):
    return signal.filtfilt(b, a, signal_1d)

AX_raw = cycle['AX'].values.astype(float)
AY_raw = cycle['AY'].values.astype(float)

AX_filt = filt(AX_raw)
AY_filt = filt(AY_raw)

# ── Time axis ──────────────────────────────────────────────────
t = np.linspace(0, duration_s, n)

# ── Integration: cumulative trapezoidal ────────────────────────
def cumtrapz(y, x):
    """cumulative trapezoidal integration, prepended with 0"""
    return integrate.cumulative_trapezoid(y, x, initial=0)

vel_X = cumtrapz(AX_filt, t)
dis_X = cumtrapz(vel_X, t)

vel_Y = cumtrapz(AY_filt, t)
dis_Y = cumtrapz(vel_Y, t)

# ── Locate open/close time indices ─────────────────────────────
open_idx  = 0   # cycle starts at '开'
close_idx = n - 1  # cycle ends at '关'
t_open  = t[open_idx]
t_close = t[close_idx]

# ── Plotting helper ────────────────────────────────────────────
def make_plot(labels_lang='zh'):
    """labels_lang: 'zh' or 'en'"""
    if labels_lang == 'zh':
        # Chinese labels
        axis_label_x = 'X轴 (开关门方向)'
        axis_label_y = 'Y轴 (垂直上下方向)'
        acc_label  = '加速度 (m/s²)'
        vel_label  = '速度 (m/s)'
        dis_label  = '位移 (m)'
        titles = [
            'X轴 - 加速度 AX',
            'Y轴 - 加速度 AY',
            'X轴 - 速度 (积分)',
            'Y轴 - 速度 (积分)',
            'X轴 - 位移 (二次积分)',
            'Y轴 - 位移 (二次积分)',
        ]
        open_label  = '开门'
        close_label = '关门'
        time_label  = '时间 (s)'
        fname = 'curves.png'
    else:
        axis_label_x = 'X-axis (Door Direction)'
        axis_label_y = 'Y-axis (Vertical Direction)'
        acc_label  = 'Acceleration (m/s²)'
        vel_label  = 'Velocity (m/s)'
        dis_label  = 'Displacement (m)'
        titles = [
            'X-axis – Acceleration AX',
            'Y-axis – Acceleration AY',
            'X-axis – Velocity (Integrated)',
            'Y-axis – Velocity (Integrated)',
            'X-axis – Displacement (Double Integrated)',
            'Y-axis – Displacement (Double Integrated)',
        ]
        open_label  = 'Door Open'
        close_label = 'Door Close'
        time_label  = 'Time (s)'
        fname = 'curves_en.png'

    fig, axes = plt.subplots(3, 2, figsize=(14, 12))
    fig.suptitle('Elevator Normal Operation – Door Cycle Curves' 
                 if labels_lang == 'en' else 
                 '电梯正常运行 – 开关门周期曲线',
                 fontsize=14, fontweight='bold')

    data_pairs = [
        (0,0, AX_filt,  titles[0], acc_label, 'blue'),
        (0,1, AY_filt,  titles[1], acc_label, 'blue'),
        (1,0, vel_X,    titles[2], vel_label, 'green'),
        (1,1, vel_Y,    titles[3], vel_label, 'green'),
        (2,0, dis_X,    titles[4], dis_label, 'red'),
        (2,1, dis_Y,    titles[5], dis_label, 'red'),
    ]

    for (ri, ci, data, title, ylabel, color) in data_pairs:
        ax = axes[ri][ci]
        ax.plot(t, data, color=color, linewidth=0.8)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel(time_label)
        ax.set_ylabel(ylabel)
        ax.grid(True, alpha=0.3)
        # Mark door open/close
        ax.axvline(x=t_open,  color='orange', linestyle='--', linewidth=1.2,
                   label=open_label)
        ax.axvline(x=t_close, color='purple', linestyle='--', linewidth=1.2,
                   label=close_label)
        # Only show legend on first row
        if ri == 0 and ci == 0:
            ax.legend(fontsize=8, loc='upper right')

    plt.tight_layout()
    plt.savefig(fname, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Saved {fname}")

# ── Generate both versions ─────────────────────────────────────
make_plot('zh')
make_plot('en')

# ── Summary ─────────────────────────────────────────────────────
print(f"\nSummary:")
print(f"  Cycle duration: {duration_s:.2f} s")
print(f"  Start row index: {cycle_start}")
print(f"  End row index:   {cycle_end}")
print(f"  Open floor:  {cycle['floor'].iloc[0]}")
print(f"  Close floor: {cycle['floor'].iloc[-1]}")
print(f"  Direction:   {cycle['dir'].iloc[0]}")
print(f"  Sampling rate: {fs:.2f} Hz")
print(f"  Filter: Butterworth low-pass, cutoff={cutoff} Hz, order={order}")
