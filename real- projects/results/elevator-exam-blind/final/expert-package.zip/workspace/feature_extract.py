#!/usr/bin/env python3
"""
电梯MEMS传感器特征提取脚本（分段版）
===================================
用法：
    python3 feature_extract.py <原始数据目录> [输出文件.jsonl]

示例：
    python3 feature_extract.py "data/正常数据集,data/故障数据集" seg_train.jsonl
    python3 feature_extract.py "data/正常数据集-test,data/故障数据集-test" seg_test.jsonl

输入：
    原始数据目录路径，或逗号分隔的多个目录路径
    每个目录下是 .xlsx 文件

分段策略：
    - 正常文件（status列含'开'/'关'）：按'开'事件切分为开关门周期
    - 故障文件（status列不含'开'/'关'）：用AX轴活动检测切分为活动片段

输出：
    JSONL 文件，每行格式: {"features": {"feat1": 0.1, ...}, "label": 0|1}
    label: 0=正常, 1=故障

依赖：
    pip install numpy pandas openpyxl scipy
"""

import sys
import os
import json
import numpy as np
import pandas as pd
from scipy import stats as sp_stats
from scipy.fft import rfft, rfftfreq

FS = 5.0  # 采样频率 Hz


# ============================================================
# 特征提取函数（97个特征，与ft.jsonl完全一致）
# ============================================================

def extract_features_from_df(df: pd.DataFrame) -> dict:
    """从单个数据点的DataFrame提取特征（97个特征）"""
    n = len(df)
    if n < 10:
        return None

    feats = {}
    # === 基础统计：时长与点数 ===
    feats['duration_s'] = n / FS
    feats['n_points'] = n

    # === 各轴时域统计特征 ===
    for col in ['AX', 'AY', 'AZ', 'GX', 'GY', 'GZ']:
        if col not in df.columns:
            continue
        s = df[col].values.astype(np.float64)
        prefix = col

        feats[f'{prefix}_mean'] = float(np.mean(s))
        feats[f'{prefix}_std'] = float(np.std(s))
        feats[f'{prefix}_min'] = float(np.min(s))
        feats[f'{prefix}_max'] = float(np.max(s))
        feats[f'{prefix}_range'] = float(np.max(s) - np.min(s))
        feats[f'{prefix}_rms'] = float(np.sqrt(np.mean(s ** 2)))

        # 偏度与峰度
        feats[f'{prefix}_skew'] = float(sp_stats.skew(s))
        feats[f'{prefix}_kurt'] = float(sp_stats.kurtosis(s))

        # 过零率
        zc = np.sum(np.abs(np.diff(np.sign(s - np.mean(s))))) / n
        feats[f'{prefix}_zcr'] = float(zc)

        # 一阶差分统计（反映变化速率）
        diff = np.diff(s)
        feats[f'{prefix}_diff_std'] = float(np.std(diff))
        feats[f'{prefix}_diff_max'] = float(np.max(np.abs(diff)))

    # === 频域特征（仅加速度轴 AX/AY/AZ） ===
    for col in ['AX', 'AY', 'AZ']:
        if col not in df.columns:
            continue
        s = df[col].values.astype(np.float64)
        s_detrended = s - np.mean(s)
        fft_vals = np.abs(rfft(s_detrended))
        freqs = rfftfreq(n, d=1.0 / FS)

        # 总能量
        feats[f'{col}_fft_energy'] = float(np.sum(fft_vals ** 2))

        # 分频段能量比
        bands = {
            'low': (0.1, 0.5),
            'mid': (0.5, 1.5),
            'high': (1.5, 2.5),
        }
        total_e = feats[f'{col}_fft_energy']
        for band_name, (lo, hi) in bands.items():
            mask = (freqs >= lo) & (freqs <= hi)
            band_e = float(np.sum(fft_vals[mask] ** 2))
            if total_e > 1e-10:
                feats[f'{col}_fft_{band_name}_ratio'] = band_e / total_e
            else:
                feats[f'{col}_fft_{band_name}_ratio'] = 0.0

        # 主导频率（排除 DC）
        if len(fft_vals) > 1:
            dom_idx = np.argmax(fft_vals[1:]) + 1
            feats[f'{col}_dom_freq'] = float(freqs[dom_idx])
        else:
            feats[f'{col}_dom_freq'] = 0.0

        # 频谱质心
        if total_e > 1e-10:
            feats[f'{col}_spectral_centroid'] = float(
                np.sum(freqs * fft_vals) / np.sum(fft_vals)
            )
        else:
            feats[f'{col}_spectral_centroid'] = 0.0

    # === 轴间相关性 ===
    acc_pairs = [('AX', 'AY'), ('AX', 'AZ'), ('AY', 'AZ')]
    for c1, c2 in acc_pairs:
        if c1 in df.columns and c2 in df.columns:
            feats[f'corr_{c1}_{c2}'] = float(np.corrcoef(df[c1], df[c2])[0, 1])

    gyro_pairs = [('GX', 'GY'), ('GX', 'GZ'), ('GY', 'GZ')]
    for c1, c2 in gyro_pairs:
        if c1 in df.columns and c2 in df.columns:
            feats[f'corr_{c1}_{c2}'] = float(np.corrcoef(df[c1], df[c2])[0, 1])

    # === 综合特征 ===
    if 'AX' in df.columns and 'GY' in df.columns:
        feats['corr_AX_GY'] = float(np.corrcoef(df['AX'], df['GY'])[0, 1])
    if 'AX' in df.columns and 'GZ' in df.columns:
        feats['corr_AX_GZ'] = float(np.corrcoef(df['AX'], df['GZ'])[0, 1])

    # 陀螺仪总活动度
    gyro_activity = 0.0
    for col in ['GX', 'GY', 'GZ']:
        if col in df.columns:
            gyro_activity += feats[f'{col}_std']
    feats['gyro_activity'] = float(gyro_activity)

    # 加速度总振动能量
    acc_vib = 0.0
    for col in ['AX', 'AY', 'AZ']:
        if col in df.columns:
            acc_vib += feats[f'{col}_std']
    feats['acc_vibration'] = float(acc_vib)

    # AX 标准差与 AZ 标准差之比
    if feats.get('AZ_std', 0) > 1e-10:
        feats['AX_AZ_std_ratio'] = float(feats['AX_std'] / feats['AZ_std'])
    else:
        feats['AX_AZ_std_ratio'] = 0.0

    return feats


# ============================================================
# 标签判断
# ============================================================

def determine_label(filename: str) -> int:
    """根据文件名判断标签：正常=0，故障=1"""
    basename = os.path.basename(filename)
    if '正常' in basename or 'label_data' in basename:
        return 0
    elif '故障' in basename or '异常' in basename:
        return 1
    else:
        raise ValueError(f"无法判断标签: {basename}")


# ============================================================
# 文件类型判断：是否是正常文件（status列含'开'/'关'）
# ============================================================

def is_normal_file(df: pd.DataFrame) -> bool:
    """判断文件是否为正常文件：status列存在且含'开'或'关'值"""
    if 'status' not in df.columns:
        return False
    status_vals = df['status'].dropna()
    if len(status_vals) == 0:
        return False
    unique_vals = set(status_vals.astype(str).str.strip().unique())
    return ('开' in unique_vals) or ('关' in unique_vals)


# ============================================================
# 正常文件分段：按'开'事件切分开关门周期
# ============================================================

def segment_normal(df: pd.DataFrame) -> list:
    """
    对正常文件，按status=='开'切分。
    每个周期 = 从当前'开'行到下一个'开'行之前（或文件末尾）。
    返回 DataFrame 片段列表。
    """
    status_series = df['status'].astype(str).str.strip()
    open_indices = df.index[status_series == '开'].tolist()

    if len(open_indices) < 2:
        return [df]

    segments = []
    for i in range(len(open_indices)):
        start = open_indices[i]
        if i + 1 < len(open_indices):
            end = open_indices[i + 1]
        else:
            end = len(df)
        seg = df.iloc[start:end]
        segments.append(seg)

    return segments


# ============================================================
# 故障文件分段：AX轴活动检测
# ============================================================

def segment_fault(df: pd.DataFrame,
                  window: int = 25,
                  threshold: float = 0.012,
                  merge_gap: int = 10) -> list:
    """
    对故障文件，用AX轴滚动标准差检测活动片段。
    window=25 (5s), threshold=0.012, merge_gap=10 (2s).

    返回 DataFrame 片段列表。
    """
    if 'AX' not in df.columns or len(df) < window:
        return [df]

    ax = df['AX'].values.astype(np.float64)

    # 计算滚动标准差
    rolling_std = pd.Series(ax).rolling(window=window, center=True).std().values
    rolling_std = np.nan_to_num(rolling_std, nan=0.0)

    # 标记活动点：std > threshold
    active = rolling_std > threshold

    if not active.any():
        return [df]

    # 找连续活动段的起止
    segments = []
    in_burst = False
    burst_start = 0

    for i in range(len(active)):
        if active[i] and not in_burst:
            burst_start = i
            in_burst = True
        elif not active[i] and in_burst:
            segments.append((burst_start, i))
            in_burst = False
    if in_burst:
        segments.append((burst_start, len(active)))

    if not segments:
        return [df]

    # 合并间隔在 merge_gap 以内的相邻段
    merged = [segments[0]]
    for seg in segments[1:]:
        prev_start, prev_end = merged[-1]
        curr_start, curr_end = seg
        if curr_start - prev_end <= merge_gap:
            merged[-1] = (prev_start, curr_end)
        else:
            merged.append(seg)

    # 为每个活动段生成 DataFrame 片段
    result = []
    for start, end in merged:
        seg_df = df.iloc[start:end]
        if len(seg_df) >= 10:
            result.append(seg_df)

    if not result:
        return [df]
    return result


# ============================================================
# 处理单个文件：分段后提取特征
# ============================================================

def process_file(fpath: str, fname: str) -> list:
    """处理单个文件，返回 record 列表"""
    records = []
    try:
        df = pd.read_excel(fpath)
    except Exception as e:
        print(f"  读取失败 {fpath}: {e}")
        return records

    label = determine_label(fname)

    if is_normal_file(df):
        segments = segment_normal(df)
        seg_type = "status"
    else:
        segments = segment_fault(df)
        seg_type = "activity"

    for i, seg in enumerate(segments):
        if len(seg) < 10:
            continue
        feats = extract_features_from_df(seg)
        if feats is None:
            continue
        records.append({"features": feats, "label": label})

    print(f"  {fname}: {seg_type}分段 → {len(records)}个周期, label={label}")
    return records


# ============================================================
# 主处理逻辑
# ============================================================

def process_directories(dirs: list, output_path: str):
    """遍历多个目录，提取所有 xlsx 的特征，写入 JSONL"""
    records = []
    stats = {"normal_files": 0, "fault_files": 0, "normal_cycles": 0, "fault_cycles": 0}

    for d in dirs:
        d = d.strip()
        if not os.path.isdir(d):
            print(f"警告: 目录不存在, 跳过: {d}")
            continue
        for fname in sorted(os.listdir(d)):
            if not fname.endswith('.xlsx'):
                continue
            fpath = os.path.join(d, fname)
            label = determine_label(fname)

            if label == 0:
                stats["normal_files"] += 1
            else:
                stats["fault_files"] += 1

            file_records = process_file(fpath, fname)
            for rec in file_records:
                if rec["label"] == 0:
                    stats["normal_cycles"] += 1
                else:
                    stats["fault_cycles"] += 1
            records.extend(file_records)

    with open(output_path, 'w', encoding='utf-8') as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')

    print(f"\n{'='*60}")
    print(f"完成! 共 {len(records)} 条记录写入 {output_path}")
    print(f"  正常文件: {stats['normal_files']} 个 → {stats['normal_cycles']} 个周期")
    print(f"  故障文件: {stats['fault_files']} 个 → {stats['fault_cycles']} 个周期")
    if records:
        print(f"  特征数: {len(records[0]['features'])} 个")
    print(f"{'='*60}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    dir_arg = sys.argv[1]
    output = sys.argv[2] if len(sys.argv) > 2 else 'features.jsonl'

    dirs = dir_arg.split(',')
    process_directories(dirs, output)
